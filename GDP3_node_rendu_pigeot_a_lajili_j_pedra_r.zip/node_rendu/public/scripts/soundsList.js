﻿var soundManager = new NLSounds();
soundManager.channels = 7;
var soundsList = [

];

//soundManager.pushSounds(soundsList, "sound");